require 'integration_helper'

class VirtualMachinesTest < ActionDispatch::IntegrationTest
end
