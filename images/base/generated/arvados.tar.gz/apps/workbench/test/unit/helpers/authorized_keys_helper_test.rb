require 'test_helper'

class AuthorizedKeysHelperTest < ActionView::TestCase
end
