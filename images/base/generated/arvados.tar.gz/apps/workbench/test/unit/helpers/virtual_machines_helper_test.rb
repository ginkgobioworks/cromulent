require 'test_helper'

class VirtualMachinesHelperTest < ActionView::TestCase
end
