require 'test_helper'

class UserAgreementsHelperTest < ActionView::TestCase
end
