require 'test_helper'

class JobTasksHelperTest < ActionView::TestCase
end
