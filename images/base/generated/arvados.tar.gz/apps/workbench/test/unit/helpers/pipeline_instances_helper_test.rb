require 'test_helper'

class PipelineInstancesHelperTest < ActionView::TestCase
end
