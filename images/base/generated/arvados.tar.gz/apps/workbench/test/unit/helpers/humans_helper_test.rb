require 'test_helper'

class HumansHelperTest < ActionView::TestCase
end
