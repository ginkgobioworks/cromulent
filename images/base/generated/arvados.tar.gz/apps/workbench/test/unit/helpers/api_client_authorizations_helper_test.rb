require 'test_helper'

class ApiClientAuthorizationsHelperTest < ActionView::TestCase
end
