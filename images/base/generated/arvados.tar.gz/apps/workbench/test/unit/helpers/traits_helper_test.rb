require 'test_helper'

class TraitsHelperTest < ActionView::TestCase
end
