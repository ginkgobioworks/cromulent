require 'test_helper'

class PipelineTemplatesHelperTest < ActionView::TestCase
end
