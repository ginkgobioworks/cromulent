require 'test_helper'

class KeepDisksHelperTest < ActionView::TestCase
end
