require 'test_helper'

class NodesHelperTest < ActionView::TestCase
end
