require 'test_helper'

class MetadataHelperTest < ActionView::TestCase
end
