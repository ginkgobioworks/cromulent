require 'test_helper'

class SpecimensHelperTest < ActionView::TestCase
end
