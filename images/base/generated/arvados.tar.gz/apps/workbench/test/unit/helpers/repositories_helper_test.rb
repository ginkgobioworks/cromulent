require 'test_helper'

class RepositoriesHelperTest < ActionView::TestCase
end
