require 'test_helper'

class SpecimensControllerTest < ActionController::TestCase
end
