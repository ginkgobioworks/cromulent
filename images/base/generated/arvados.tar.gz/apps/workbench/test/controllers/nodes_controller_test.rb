require 'test_helper'

class NodesControllerTest < ActionController::TestCase
end
