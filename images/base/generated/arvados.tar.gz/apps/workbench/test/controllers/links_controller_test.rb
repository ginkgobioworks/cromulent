require 'test_helper'

class MetadataControllerTest < ActionController::TestCase
end
