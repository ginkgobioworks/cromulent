require 'test_helper'

class ProjectsControllerTest < ActionController::TestCase
end
