require 'test_helper'

class VirtualMachinesControllerTest < ActionController::TestCase
end
