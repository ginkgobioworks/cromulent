require 'test_helper'

class TraitsControllerTest < ActionController::TestCase
end
