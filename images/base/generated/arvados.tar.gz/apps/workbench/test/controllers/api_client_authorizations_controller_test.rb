require 'test_helper'

class ApiClientAuthorizationsControllerTest < ActionController::TestCase
end
