require 'test_helper'

class KeepDisksControllerTest < ActionController::TestCase
end
