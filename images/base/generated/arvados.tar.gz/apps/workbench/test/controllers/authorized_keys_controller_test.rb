require 'test_helper'

class AuthorizedKeysControllerTest < ActionController::TestCase
end
