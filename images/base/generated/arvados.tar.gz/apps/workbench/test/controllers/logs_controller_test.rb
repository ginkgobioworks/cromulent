require 'test_helper'

class LogsControllerTest < ActionController::TestCase
end
