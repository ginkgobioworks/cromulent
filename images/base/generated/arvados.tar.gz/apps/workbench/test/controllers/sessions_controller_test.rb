require 'test_helper'

class SessionsControllerTest < ActionController::TestCase
end
