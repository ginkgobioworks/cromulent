require 'test_helper'

class HumansControllerTest < ActionController::TestCase
end
