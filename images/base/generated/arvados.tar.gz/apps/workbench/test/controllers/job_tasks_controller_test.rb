require 'test_helper'

class JobTasksControllerTest < ActionController::TestCase
end
