class JobTasksController < ApplicationController
end
