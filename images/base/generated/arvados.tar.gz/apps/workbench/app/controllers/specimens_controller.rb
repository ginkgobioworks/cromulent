class SpecimensController < ApplicationController
end
