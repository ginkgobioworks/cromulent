class TraitsController < ApplicationController
end
