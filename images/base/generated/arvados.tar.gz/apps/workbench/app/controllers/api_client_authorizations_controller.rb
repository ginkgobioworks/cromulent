class ApiClientAuthorizationsController < ApplicationController

  def index_pane_list
    %w(Recent Help)
  end

end
