class HumansController < ApplicationController
end
