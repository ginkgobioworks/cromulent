class NodesController < ApplicationController
end
