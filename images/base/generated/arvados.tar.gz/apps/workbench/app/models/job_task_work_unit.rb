class JobTaskWorkUnit < ProxyWorkUnit
  def title
    "job task"
  end
end
