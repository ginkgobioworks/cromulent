class Trait < ArvadosBase
  def self.goes_in_projects?
    true
  end
end
