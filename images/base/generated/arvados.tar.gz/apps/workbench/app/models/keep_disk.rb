class KeepDisk < ArvadosBase
  def self.creatable?
    false
  end
end
