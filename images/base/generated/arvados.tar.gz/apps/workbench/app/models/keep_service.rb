class KeepService < ArvadosBase
  def self.creatable?
    false
  end
end
