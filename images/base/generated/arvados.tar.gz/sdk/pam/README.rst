==================
Arvados PAM Module
==================

Overview
--------

Accept Arvados API tokens to authenticate to shell accounts.

.. _Arvados: https://arvados.org

Installation
------------

See http://doc.arvados.org

Testing and Development
-----------------------

https://arvados.org/projects/arvados/wiki/Hacking
describes how to set up a development environment and run tests.
