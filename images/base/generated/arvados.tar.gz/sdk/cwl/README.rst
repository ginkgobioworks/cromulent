Arvados Common Workflow Language (CWL) runner.
